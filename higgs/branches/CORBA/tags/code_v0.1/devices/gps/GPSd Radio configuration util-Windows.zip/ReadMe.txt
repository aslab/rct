******************************************************************
***********************    PDLCONF    ****************************
******************************************************************

Thank you for purchasing the Positioning Data Link system of radio
modem products optimized for survey applications.

This Readme.txt file contains information concerning the PDLCONF
configuration utility.  This utility allows you to view, edit and
print the configuration of your PDL radio modem.  It also includes
frequency table upgrade and firmware upgrade capabilities.  We
recommend that you print this file for future reference.

If you have questions or comments concerning this product, please
contact Pacific Crest Corporation customer support center:
    Phone   (800) 795-1001 (US & Canada)
            (408) 653-2070 (International or local)
    Fax     (408) 748-9984
    E-mail  sales@pacificcrest.com or support@pacificcrest.com
    Web     www.pacificcrest.com

Note that versions of the latest software and firmware for the
PDL are available in the downloads area of www.pacificcrest.com.

Important Notice

This version of PDLCONF is designed to operate with current
and earlier versions of PDL hardware.  Always use the latest
software revision supplied with your PDL to take advantage
of features not previously available.  We recommend that you
remove old revisions of software from your computer to prevent
inadvertant use with the latest hardware.  Never use RFMCONF
or other Pacific Crest Corporation utilities with the PDL
products.

1) Installation

The PDLCONF sofware has been installed on your computer in

       C:\Program Files\PCC

subdirectory and a shortcut to the PDLCONF.EXE has been
added to your desk-top (unless otherwise specified).

2) Uninstall

Should you wish to remove PDLCONF from your computer,
double-click My Computer (on the desk-top), then double-
click Control Panel, then double-click Add/Remove Program.
Select PDLCONF and click on Add/Remove.

3) System requirements

Minimum Intel 486 computer with 16 MB of RAM
5 MB of hard disk space
Operating system - Windows 95/98/ME, Windows NT, 
Windows 2000, or Windows XP.

4) Revision History

1.00    Initial release
1.10    FW upgrade feature added
        Channel table upgrade feature added
        OEM specific configuration capability added
1.11    Fix to channel table upgrade bug
1.12    Sokkia defaults have been changed.
1.13    Data Security fields added
        Trimtalk 450s protocol added
        Rover Auto-Off parameter added
1.20    Readable configuration file
        Improved vendor support
        Power Control setting added
        Improved firmware download
1.30	RFMRXO support.
2.00    PDL LP and HP support, numerous minor fixes.
2.10    Fix modem enable handling; ensure only
        valid settings shown for PDL Spare.
2.20    Correct receiver defaults, fix bug with 
        Restore Defaults processing.
2.30    Prevent use with EDL modems.
2.32    Correct error reading/setting FEC.
2.40	Fix bugs per ECN X01752:
		- PDLCONF no longer works with EDL
		- Included freq band 223-235 Mhz for the PDL LPB and RXO 
		- factory defaults correct on Rover
		- active channel must be defined now 
		- FEC Control Byte correct
		- Demo Mode faster
		- Firmware Pre-Loading understood
		- Firmware Loading Faster
		- Fixed FW Load problems some W2K machines
		- Added VHF factory default frequencies
		- Updated Help File
		- Improved Icon
2.41	Factory Only Release
		- Will not crash or inhibit program if memory all FF's (brain dead unit)
2.42	Fixed Bugs
		- OEM Software Support
4.0   Added RFM support for latest modem hardware & 5.06 & up firmware
      Fixed following bugs
            - Changed program error messages from confusing jargon to rational content
            - Modified to work with USB to serial RS232 adapter
            - Unprogrammed channel may no longer be selected
            - 0 watts now is displayed for Rover
            - Locate modem button not available when no com ports are available
            - Changed TAB key ordering
            - Corrected Copyright date
            - UPG file problem fixed
            - Auto Rover on HPB button fixed
            - Win 2000 and Win XP compatibility fixed
      


(C)opyright 1999 - 2004, Pacific Crest Corporation
