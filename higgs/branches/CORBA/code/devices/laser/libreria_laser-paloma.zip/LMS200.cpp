
#include "LMS200.h"

LMS200::LMS200(void)
{
	pthread_mutex_init(&mutex,NULL);
	new_data=0;
	max_range = 1;
}

LMS200::~LMS200(){}

void LMS200::initialValues(int baud, const char* p, int range, int res, int unit, int max_r)
{
	baud_sel=baud;
	strcpy(port,p);
	range_mode=range;
	res_mode=res;
	unit_mode=unit;
	max_range=max_r;
	printf (" Init max_range = %d", max_range);
}


// Calculates the CRC for packets sent to/from the LMS
unsigned short LMS200::LMSCRC(unsigned char* theBytes, int lenBytes)
{
  unsigned char xyz1 = 0;
  unsigned char xyz2 = 0;
  unsigned short uCrc16 = 0;
  int i;
  for (i = 0; i < lenBytes; i++) {
    xyz2 = xyz1;
    xyz1 = theBytes[i];

    if (uCrc16 & 0x8000) {
      uCrc16 = (uCrc16 & 0x7fff) << 1;
      uCrc16 = uCrc16 ^ 0x8005;
    }
    else {
      uCrc16 = uCrc16 << 1;
    }
    uCrc16 = uCrc16 ^ (xyz1 | (xyz2 << 8));
  }
  return uCrc16;
}

uchar LMS200::msgcmp(int len1, const uchar *s1, int len2, const uchar *s2)
{
  int i;
  if (len1 != len2) {
  //  printError2("msgcmp - message lengths didn't match", len1, len2);
    return FALSE;
  }
  for(i=0; i<len1; i++) {
    if (s1[i] != s2[i]) {
  //    printError2("msgcmp - character didn't match", s1[i], s2[i]);
      return FALSE;
    }
  }
  unsigned short crcval = LMSCRC((unsigned char*)s1, len1);
  if ((crcval & 0xff) != s2[len2]) {
    printError2("msgcmp - CRC didn't match1", crcval & 0xff, s2[len2-2]);
    return FALSE;
  }
  if (((crcval >> 8) & 0xff) != s2[len2+1]) {
    printError2("msgcmp - CRC didn't match2",(crcval >> 8) & 0xff, s2[len2-1]);
    return FALSE;
  }

  return TRUE;
}

// Writes a message to the LMS
void LMS200::wtLMSmsg(int fd, int len, const uchar *msg)
{
  int i;
  unsigned short crcval = LMSCRC((unsigned char*)msg, len);
  unsigned char sendchar;

  for (i = 0; i < len; i++) {
    sleep55us();
    write(fd,(const void*) (msg+i),1);
  }

  sendchar = crcval & 0xff;
  sleep55us();
  write(fd, (const void *) &sendchar, 1);
  sendchar = (crcval >> 8) & 0xff;
  sleep55us();
  write(fd, (const void *) &sendchar, 1);


#ifdef DEBUG
  printf("write msg: ");
  for(i=0;i<len; i++) printf("%02x ",msg[i]);
  printf("%02x %02x\n", crcval & 0xff, (crcval >> 8) & 0xff);
#endif
}

int LMS200::rdLMSmsg(int fd, int len, const uchar *buf)
{
  int sumRead=0,nRead=0,toRead=len,n;
  static struct timeval tv0;
  static fd_set rfds;
  tv0.tv_sec = 0;
  tv0.tv_usec = 500000;
  FD_ZERO (&rfds);
  FD_SET(fd, &rfds);

#ifdef DEBUG
  int i;
  printf("read msg: ");
#endif
  while(toRead>0){
    n=toRead>255 ? 255:toRead;
    toRead-=n;
    if (select(fd+1, &rfds, NULL, NULL, &tv0)) {
      nRead=read(fd,(void *)(buf+sumRead),n);
    }
    else {
      nRead = 20; // just to keep it going
 //     printError("rdLMSmsg - timeout error in multi-byte read\n");
    }
#ifdef DEBUG
    for(i=0;i<nRead; i++) printf("%02x ",buf[i]);
#endif
    sumRead+=nRead;
    if(nRead!=n) break;
  }
#ifdef DEBUG
  printf("\n");  
#endif
  return nRead;
}

uchar LMS200::rdLMSbyte(int fd)
{
  uchar buf;
  static struct timeval tv0;
  static fd_set rfds;
  tv0.tv_sec = 0;
  tv0.tv_usec = 100000;//DRL was 100000

  FD_ZERO (&rfds);
  FD_SET(fd, &rfds);
  if (select(fd+1, &rfds, NULL, NULL, &tv0)) {
    read(fd,&buf,1);
//#ifdef DEBUG
//    printf("read byte: %02x\n", buf);
//#endif
  }
  else {
//    printError("rdLMSbyte - timeout Error\n");
    buf = 0;
  }
  return buf;
}


/*procedure that shows the laser measurements. Format: 
Timestamp
v0  v1  v2  ... v19
v10 v21 v22 ... v39
...
The total number of measurements is dependent on the resolution
and angular range selected*/
void LMS200::showsavedata(int len, uchar *buf, double* buffer)
{
  struct timeval now;
  struct timezone tz;
  int i,hr,min,sec;
  double val;
 // FILE* f=NULL;
 // f=fopen("/home/raul/Desktop/linux/Data/Fichero","a");
  //if(f==NULL) printf("No se pudo crear fichero\n");
  gettimeofday(&now,&tz);
  hr=(now.tv_sec/3600 % 24 - tz.tz_minuteswest/60) % 24;
  min=(now.tv_sec % 3600)/60;
  sec=now.tv_sec % 60;
  printf("\n%02d:%02d:%02d.%03ld  ",hr,min,sec,now.tv_usec/1000);
 // fprintf(f,"\n%02d:%02d:%02d.%03ld  ",hr,min,sec,now.tv_usec/1000);
  /*each value are represented by 16 bits*/
  /*only the lower 12 bits are significant*/
  
  for(i=0; i<len; i=i+2) {
    if((i % 40) ==0){ printf("\n%d:",i/2);}
    val=(double)( (buf[i+1] & 0x1f) <<8  |buf[i]);
    printf("%5.0f ", val);
    buffer[(i/2)+2]=val;
  }
  printf("\n"); 
  


}


/*return true if the ACK packet is as expected*/
uchar LMS200::chkAck(int fd, int ackmsglen, const uchar *ackmsg)
{
  int i,buflen;
  uchar buf[MAXNDATA];

  /*the following is to deal with a possibly timing issue*/
  /*the communication occasionally breaks without this*/
  usleep(100000); 
  for(i=0;i<MAXRETRY;i++) {
    if(rdLMSbyte(fd)==ackmsg[0]) break;
  }
  buflen=rdLMSmsg(fd,ackmsglen+1,buf);
  return msgcmp(ackmsglen-1,ackmsg+1,buflen-2,buf);
}



/*set the communication speed and terminal properties*/
int LMS200::initLMS(const char *serialdev)
{
  int fd;
  const uchar *msg;
  tcflag_t cflagval;
  struct termios newtio_struct, *newtio=&newtio_struct;
  //OPEN PORT
  fd = open(serialdev, O_RDWR | O_NOCTTY ); 
  if (fd <0) {
    printError1("initLMS - Error opening 1", fd);
    perror(serialdev);
    exit(-1);
  }
        
  tcgetattr(fd,&OLDTERMIOS); /* save current port settings */

  /*after power up, the laser scanner will reset to 9600bps*/
  memset(newtio, 0, sizeof(struct termios));
   //newtio->c_cflag = B38400 | CS8 | CLOCAL | CREAD;//DRL
 newtio->c_cflag = B9600 | CS8 | CLOCAL | CREAD;
  newtio->c_iflag = IGNPAR;
  newtio->c_oflag = 0;
        
  /* set input mode (non-canonical, no echo,...) */
  newtio->c_lflag = 0;
  newtio->c_cc[VTIME]    = 10;   /* inter-character timer unused */
  newtio->c_cc[VMIN]     = 255;   /* blocking read until 1 chars received */
  tcflush(fd, TCIFLUSH);
  tcsetattr(fd,TCSANOW,newtio);

  if (baud_sel == BAUD_500000) { // step to the 500000bps mode
    msg = PCLMS_B500000;
    cflagval = B500000 | CS8 | CLOCAL | CREAD;
  }
  else if (baud_sel == BAUD_38400) { // step to the 38400bps mode
    msg = PCLMS_B38400;
    cflagval = B38400 | CS8 | CLOCAL | CREAD;
  }
  else if (baud_sel == BAUD_19200) { // step to the 19200bps mode
    msg = PCLMS_B19200;
    cflagval = B19200 | CS8 | CLOCAL | CREAD;
  }
  else {
    // Do nothing - goal is 9600 and already at 9600
    return fd;
  }

  wtLMSmsg(fd,sizeof(PCLMS_B500000)/sizeof(uchar),msg);
  if(!chkAck(fd,sizeof(LMSPC_CMD_ACK)/sizeof(uchar),LMSPC_CMD_ACK))
  {
    printError("****initLMS - Baud rate changes failure\n");
  }

  // set the PC side as well    
  tcflush(fd, TCIFLUSH);
  close(fd);
  //usleep(10000000); // DRL 
  usleep(400000); //  This is needed on the faster kernels otherwise the
  // open statement on the next line fails
  fd = open(serialdev, O_RDWR | O_NOCTTY );
  if (fd <0) {
    printError1("initLMS - Error opening 2", fd);
    perror(serialdev);
    exit(-1);
  }
  newtio->c_cflag = cflagval;

  tcflush(fd, TCIFLUSH);
  tcsetattr(fd,TCSANOW,newtio);
  tcflush(fd, TCIFLUSH);
  return fd;
}


// Sets the sweep width and resolution
int LMS200::setRangeRes(int fd, int res)
{
  const uchar *msg, *ackmsg;
  int retval = 0;

  /*change the resolution*/
  switch(res){
  case (RES_1_DEG | RANGE_100): 
    msg=PCLMS_RES1;
    ackmsg=LMSPC_RES1_ACK;
    break;
  case (RES_0_5_DEG | RANGE_100):
    msg=PCLMS_RES2;
    ackmsg=LMSPC_RES2_ACK;
    break;
  case (RES_0_25_DEG | RANGE_100):
    msg=PCLMS_RES3;
    ackmsg=LMSPC_RES3_ACK;
    break;
  case (RES_1_DEG | RANGE_180):
    msg=PCLMS_RES4;
    ackmsg=LMSPC_RES4_ACK;      
    break;
  case (RES_0_5_DEG | RANGE_180):
    msg=PCLMS_RES5;
    ackmsg=LMSPC_RES5_ACK;
    break;
  default:
    printError("Invalid resolution selected. Drop back to default\n");
    msg=PCLMS_RES1;
    ackmsg=LMSPC_RES1_ACK;
    break;
  }

  // the following two line works only because msg & ackmsg are const uchar str
  wtLMSmsg(fd,sizeof(PCLMS_RES1)/sizeof(uchar),msg);
  if(!chkAck(fd,sizeof(LMSPC_RES1_ACK)/sizeof(uchar),ackmsg)) {
    printError("setRangeRes - Resolution mode setting failure\n");
    retval = 1;
  }
  return retval;
}


int LMS200::setMaxRange(int fd, int max_r)
{
	printf("setMAxRange\n");
	const uchar *msg, *ackmsg;
	//uchar *msg, *ackmsg;
 	int retval = 0;
 	
 	int ret=ChangeMode(fd, PROT_LMS_MODE_INSTALLATION);
	if(ret!=PROT_LMS_OK)
	{
		printf("Error mode installation\n");
		return ret;
	}
 	
 	switch(max_r){
 	/*case (LMS_MAX_RANGE_8M):
 		msg=PCLMS_RANGE_8M;
    	//ackmsg=LMSPC_RANGE_8M_ACK;
    	break;*/
 	case (LMS_MAX_RANGE_16M):
 		msg=PCLMS_RANGE_16M;
    	//ackmsg=LMSPC_RANGE_16M_ACK;
    	break;	
 	case (LMS_MAX_RANGE_32M):
 		msg=PCLMS_RANGE_32M;
    	//ackmsg=LMSPC_RANGE_16M_ACK;
    	break;
 	default:
 	   printError("Invalid max range selected. Drop back to default\n");
    	return 0;
    	//msg=PCLMS_RANGE_8M;
    	//ackmsg=LMSPC_RANGE_8M_ACK;
    	//break;
 	}
 	
 	/*printf("setting max range\n");
 	msg[0]=0x02;
 	msg[1]=0x00;
 	msg[2]=0x22;//33 bytes
	msg[3]=0x00;
	//Command
	msg[4]=0x77;
	//data
	msg[5]=0x00;//Blanking default
	msg[6]=0x00;//Blanking default
	msg[7]=0x46;//70mV
	msg[8]=0x00;//70mV
	msg[9]=0x00;
	if(max_r==LMS_MAX_RANGE_8M)
	{
		msg[10]=(unsigned char)1;
		printf("8m\n");
	}
	if(max_r==LMS_MAX_RANGE_16M)
	{
		msg[10]=(unsigned char)3;
		printf("16m\n");
	}
	if(max_r==LMS_MAX_RANGE_32M)
	{
		msg[10]=(unsigned char)5;
		printf("32m\n");
	}
	msg[11]=1;//units mm
	msg[12]=0;//default temporary
	msg[13]=0;//default field
	msg[14]=2;//default multiple
	for(int i=0;i<23;i++)
		msg[15+i]=0;//contour A		
		
	const uchar* message;
	message = msg;*/
 	
 	// the following two line works only because msg & ackmsg are const uchar str
  wtLMSmsg(fd,sizeof(msg)/sizeof(uchar),msg);
  
  
  /*if(!chkAck(fd,sizeof(LMSPC_RANGE_8M_ACK)/sizeof(uchar),ackmsg)) {
  //  printError("setRangeRes - Resolution mode setting failure\n");
    retval = 1;
  }*/
  
  const uchar resp= rdLMSbyte(fd);
  if(resp==0x15)
  {
  		printError("error nack \n");
  		printf("read byte: %02x\n", resp);
  		retval= 1;
  }
  
  else
  {
	  if(resp!=0x06)
	  {
	  		printError("error miss ack \n");
	  		printf("read byte: %02x\n", resp);
	  		retval= 2;
	  }
	}
	
	ret=ChangeMode(fd, PROT_LMS_MODE_SCAN_ON_REQUEST);
	if(ret!=PROT_LMS_OK)
	{
		printf("Error mode on request\n");
		return ret;
	}
  
  return retval;

}


// Sends the password to enable changing the mode
int LMS200::sendPassword(int fd)
{
  /*invoking setting mode*/
  int retval = 0;
  wtLMSmsg(fd,sizeof(PCLMS_SETMODE)/sizeof(uchar),PCLMS_SETMODE);
  if(!chkAck(fd,sizeof(LMSPC_CMD_ACK)/sizeof(uchar),LMSPC_CMD_ACK)) {
    printError("sendPassword - Measurement mode setting failure\n");
    retval = 1;
  }
  return retval;
}


// Selects mm/cm
// This message causes the red signal to light on an LMS291 - reason unknown
int LMS200::setUnits(int fd, int unit)
{
  int retval = 0;
  uchar msg[100], ackmsg[100];
  memcpy(msg, PCLMS_MM, sizeof(PCLMS_MM));
  memcpy(ackmsg, LMSPC_MM_ACK, sizeof(LMSPC_MM_ACK));
  /*change the measurement unit*/
  /*may need to increase the timeout to 7sec here*/
  if (unit == MMMODE) {
    // No change is required since MM is the default
  }
  else if (unit == CMMODE) {
    msg[11] = 0x00;
  }
  else {
    printError("setUnits - Invalid units specified\n");
  }

  // The ACK contains the original message data
  memcpy(ackmsg+7, msg+5, sizeof(PCLMS_MM) - 5);

  // the following two line works only because msg & ackmsg are const uchar str
  wtLMSmsg(fd,sizeof(PCLMS_MM)/sizeof(uchar),msg);
  if(!chkAck(fd,sizeof(LMSPC_MM_ACK)/sizeof(uchar),ackmsg)) {
 //   printError("setUnits - Measurement mode setting failure2\n");
    retval = 1;
  }
  return retval;
}

/*tell the scanner to enter the continuous measurement mode*/
int LMS200::startLMS(int fd)
{
  int retval = 0;
  wtLMSmsg(fd,sizeof(PCLMS_START)/sizeof(uchar),PCLMS_START);
  if(!chkAck(fd,sizeof(LMSPC_CMD_ACK)/sizeof(uchar),LMSPC_CMD_ACK)) {
  //  printError("startLMS - LMS fails to start\n");
	printf("Laser Wait....\n");
    retval = 1;
  }
  return retval;
}


/*stop the continuous measurement mode*/
void LMS200::stopLMS(int fd)
{
  wtLMSmsg(fd,sizeof(PCLMS_STOP)/sizeof(uchar),PCLMS_STOP);
 // if(!chkAck(fd,sizeof(LMSPC_CMD_ACK)/sizeof(uchar),LMSPC_CMD_ACK))
 //   printError("stopLMS - LMS fails to stop\n");
	
}


/*check the status bit of the measurement*/
void LMS200::chkstatus(uchar c)
{
  switch(c & 0x07){
  case 0: printError("chkstatus - no error\n"); break;
  case 1: printError("chkstatus - info\n"); break;
  case 2: printError("chkstatus - warning\n"); break;
  case 3: printError("chkstatus - error\n"); break;
  case 4: printError("chkstatus - fatal error\n"); break;
  default: printError1("chkstatus - unknown error", c); break;
  }
  if(c & 0x40) 
    printError("chkstatus - implausible measured value\n");
  if(c & 0x80)
    printError("chkstatus - pollution\n");
}

/*reset terminal and transfer speed of laser scanner before quitting*/
void LMS200::resetLMS(int fd)
{
  wtLMSmsg(fd,sizeof(PCLMS_B9600)/sizeof(uchar),PCLMS_B9600);
  if(!chkAck(fd,sizeof(LMSPC_CMD_ACK)/sizeof(uchar),LMSPC_CMD_ACK))
//    printError("resetLMS - Baud rate changes failure\n");

  tcflush(fd, TCIFLUSH);
  tcsetattr(fd,TCSANOW,&OLDTERMIOS);
  close(fd);
}

/*trap a number of signals like SIGINT, ensure the invoke
  of resetLMS() before quitting*/
void LMS200::sig_trap(int sig)
{ 
  printError("sig_trap - Premature termination\n");
  stopLMS(LMS_FD);
  resetLMS(LMS_FD);
  exit(sig);
}

int LMS200::connectToLMS()
{
  static int fd = -1;
  int retval = 0;
  int numTrys = 1;


  /*initialisation*/
  for (numTrys = 1; numTrys < 25; numTrys++) {
    retval = 0;

    #ifdef DEBUG
    //printf("trying to connect %d\n", numTrys);
    #endif

    // Set the baud rate of the PC and the LMS
    fd=initLMS(port);
    LMS_FD=fd;

   /* if  ((signal(SIGTERM, sig_trap) == SIG_ERR) ||
	 (signal(SIGHUP, sig_trap)  == SIG_ERR) ||
         (signal(SIGINT, sig_trap)  == SIG_ERR) ||
	 (signal(SIGQUIT, sig_trap) == SIG_ERR) ||
	 (signal(SIGABRT, sig_trap) == SIG_ERR)) {
      printError("connectToLMS - Cannot catch the signals\n");
    }*/

    /*mode setting*/
    retval |= setRangeRes(fd, range_mode | res_mode);
    retval |= sendPassword(fd); // this enables the following command
    retval |= setUnits(fd, unit_mode);
    printf("max_range setting = %d \n", max_range);
    if (max_range!= LMS_MAX_RANGE_8M)
    {
    	retval |= setMaxRange(fd, max_range);
    	printf("max range not 8\n");
    }
    retval |= startLMS(fd);

    if (retval == 0) {
      // LMS is working
      printf("connected to LMS\n");
      return fd;
    }
    else {
      // Tell the LMS to stop sending and set baud to 9600

      // Reset the LADAR to put it into a known state
      stopLMS(fd);
      resetLMS(fd);
	  printf("not connected to LMS\n");
  //    printError2("connectToLMS - Failed to connect", retval, numTrys);
    }
  }
  printError1("Failed to connect to ladar after many tries!", numTrys);
  exit(0);
}

int LMS200::readLMSdata(int fd, int* values)
{

  uchar buf[MAXNDATA];
  unsigned short realCRC = 0;
  int datalen;
  buf[0] = 0;

  while (buf[0] != 0x02) 
  {
    buf[0] = rdLMSbyte(fd);
  }
  
  buf[1] = rdLMSbyte(fd); // should be the ADR byte, ADR=0X80 here
  // LEN refers to the packet length in bytes, datalen 
  // refers to the number of measurements, each of them are 16bits long
  buf[2] = rdLMSbyte(fd); // should be the LEN low byte
  buf[3] = rdLMSbyte(fd); // should be the LEN high byte
  buf[4] = rdLMSbyte(fd); // should be the CMD byte, CMD=0xb0 in this mode
  buf[5] = rdLMSbyte(fd); // samples low byte
  buf[6] = rdLMSbyte(fd); // samples high byte
  
  // only lower 12 bits of high byte are significant 
  datalen = buf[5] | ((buf[6] & 0x1f) << 8);
  //printf("datalen=%d\n",datalen);
  datalen = datalen * 2; /*each reading is 2 bytes*/

  // Check that we have a valid ADR byte, valid data length and valid CMD byte
  if ((datalen > MAXNDATA) ||
      (0x80 != buf[1]) ||
      (0xb0 != buf[4])) {
    return 0;
  }


  rdLMSmsg(fd,datalen,buf+7);

  int j=0;
  for(int i=7; i<6+datalen; i+=2, j++)
  {
	  int val=(int)( (buf[i+1] & 0x1f) <<8  |buf[i]);
	  values[j]=val;
  }
  

  buf[datalen + 7] = rdLMSbyte(fd); // Status byte
  buf[datalen + 8] = rdLMSbyte(fd); // should be CRC low byte*/
  buf[datalen + 9] = rdLMSbyte(fd); // should be CRC high byte*/
  realCRC = buf[datalen+8] | (buf[datalen+9] << 8); 
  
  
  int lenBytes = datalen+8;
  unsigned short CRCcalculated;
  CRCcalculated = LMSCRC(buf, lenBytes);
  
  
  if (CRCcalculated != realCRC) {
    printError2("readLMSdata - CRC Error ", CRCcalculated, realCRC);
    return 0;
  }
  return datalen; // return 0 on error (0 valid samples)
}

int LMS200::Init(const char* port)
{
	int mode = LMS_MAX_RANGE_8M;
	initialValues(BAUD_9600, port, RANGE_100, RES_1_DEG, MMMODE, mode);
	range_mode=RANGE_180;

	//if(strncmp(optarg,"cm",2)==0) laser.unit_mode=CMMODE;	
	
	baud_sel = BAUD_500000;
	baud_sel = BAUD_38400;
	//else if (strncmp(optarg, "38400",5) == 0) laser.baud_sel = BAUD_38400;
	//else if (strncmp(optarg, "19200",5) == 0) laser.baud_sel = BAUD_19200;
	//else laser.baud_sel = BAUD_9600;
	//break;
	
	//pthread_create(&writefile,NULL,&WriteData,NULL);	
	
	//cout<<"Estableciendo una comunicación de 500K con 1 Res y Range 180º"<<endl;
	//cout<<"Estabilizando..."<<endl;
	
	// initialisation - put the LMS in a mode where it constantly sends data
	
	m_fd = connectToLMS();
	printf("Laser a 500Kb Estable!");	
	return 1;
}
void LMS200::Update()
{
	int meas[400];

	int datalen = readLMSdata(m_fd,meas);

	pthread_mutex_lock(&mutex);

		num_meas=datalen/2;
		memcpy(measurements,meas,sizeof(measurements));
		new_data=1;
	
	pthread_mutex_unlock(&mutex);
}

int LMS200::GetLaserData(int* num_med, int* meas)
{
	pthread_mutex_lock(&mutex);
	
	//meas=&(measurements[0]);
	*(num_med)=num_meas;
	for (int i=0;i<num_meas;i++)
	{
		meas[i]=measurements[i];
	}
	int ret=new_data;
	new_data=0;
	pthread_mutex_unlock(&mutex);

	return ret;
}


int LMS200::ChangeMode(int fd, int mod)
{
	if(mod!=PROT_LMS_MODE_SCAN_ON_REQUEST
		&&mod!=PROT_LMS_MODE_INSTALLATION)
		printf ("change mode error: bad parameter\n");
		
	uchar* msg;
	msg[0] = 0x02;
	msg[1] = 0x00;
	//Longitud
	if(mod==PROT_LMS_MODE_INSTALLATION)
	{
		msg[2]=0x0A;
		msg[3]=0x00;
	}
	else
	{
		msg[2]=0x02;
		msg[3]=0x00;
	}
	//Comando
	msg[4]=0x20;
	//DATO
	msg[5]=(unsigned char)mod;
	int len;
	if(mod==PROT_LMS_MODE_INSTALLATION)
	{
		msg[6]='S';msg[7]='I';msg[8]='C';msg[9]='K';msg[10]='_';msg[11]='L';msg[12]='M';msg[13]='S';
		len=14;
	}
	else len=6;
//Send Telegram
	wtLMSmsg(fd,sizeof(msg)/sizeof(uchar),msg);
//Receive
//Check Acknowledge
	
	const uchar resp= rdLMSbyte(fd);
	if(resp==0x15)
	{
		printf("nack mode\n");
		return PROT_LMS_ERROR_NACK;
	}
	if(resp!=0x6)
	{
		printf("ack mode\n");
	 	return PROT_LMS_ERROR_MISS_ACK;
	}
//Receive message


/*	int expected_length=9;
	num_read=port->Receive(expected_length,telegram_in);
	if(num_read<0)return num_read;//PORT ERROR= TIMEOUT OR READFILE
	if(num_read!=expected_length)return PROT_LMS_ERROR_ANSWER_LENGTH;
	if(telegram_in[0]!=0x02)return PROT_LMS_ERROR_TELEGRAM_FORMAT;//BEGIN
	if(telegram_in[1]!=0x80)return PROT_LMS_ERROR_TELEGRAM_FORMAT;//ADDRESS+80
	if(telegram_in[2]!=0x03)return PROT_LMS_ERROR_TELEGRAM_FORMAT;//LENGTH_L 3bytes
	if(telegram_in[3]!=0x00)return PROT_LMS_ERROR_TELEGRAM_FORMAT;//LENGTH_H
	if(telegram_in[4]!=0xA0)return PROT_LMS_ERROR_TELEGRAM_FORMAT;//COMMAND+80
	if(telegram_in[5]!=0x00)return PROT_LMS_ERROR_TELEGRAM_FORMAT;//DATA
	if(telegram_in[6]!=0x10)return PROT_LMS_ERROR_TELEGRAM_STATUS;//STATUS
	check_sum.entero=CreateCRC(telegram_in,7);
	if(telegram_in[7]!=check_sum.car_ent.caracter_low)	return PROT_LMS_ERROR_TELEGRAM_CRC;//LENGTH_H
	if(telegram_in[8]!=check_sum.car_ent.caracter_high)return PROT_LMS_ERROR_TELEGRAM_CRC; */
	
	uchar telegram_in[9];
	unsigned short crcval;
	for(int i=0;i<9;i++)
	{
		const uchar resp= rdLMSbyte(fd);
		telegram_in[i] = resp;
		switch(i)
		{
			case 0:
				if (resp!=0x02) 
					return PROT_LMS_ERROR_TELEGRAM_FORMAT;
			case 1:
			 	if (resp!=0x80) 
					return PROT_LMS_ERROR_TELEGRAM_FORMAT;
			case 2:
			 	if (resp!=0x03) 
					return PROT_LMS_ERROR_TELEGRAM_FORMAT;
			case 3:
			 	if (resp!=0x00) 
					return PROT_LMS_ERROR_TELEGRAM_FORMAT;
			case 4:
			 	if (resp!=0xA0) 
					return PROT_LMS_ERROR_TELEGRAM_FORMAT;
			case 5:
			 	if (resp!=0x00) 
					return PROT_LMS_ERROR_TELEGRAM_FORMAT;
			case 6:
			 	if (resp!=0x10) 
					return PROT_LMS_ERROR_TELEGRAM_STATUS;
			case 7:
			{
				crcval = LMSCRC(telegram_in, 7);
				uchar low_CRC_byte = crcval & 0xff;
				if (resp!= low_CRC_byte)
					return PROT_LMS_ERROR_TELEGRAM_CRC;		
			}
			case 8:
			{
				uchar high_CRC_byte = (crcval >> 8) & 0xff;
				if (resp!= high_CRC_byte)
					return PROT_LMS_ERROR_TELEGRAM_CRC;				
			}		
					
		}
			
	}
	
	
	
//All OK
	return PROT_LMS_OK;
}

