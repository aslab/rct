
#ifndef __LASER_H_
#define __LASER_H_

#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <stdio.h>
#include <sys/time.h>
#include <time.h>
#include <signal.h>
#include <getopt.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <pthread.h>

#define _POSIX_SOURCE 1 /* POSIX compliant source */
#define FALSE 0
#define TRUE 1
#define MAXRETRY 25
#define MAXNDATA 802
#define STX 0x02   /*every PC->LMS packet is started by STX*/ 
#define ACKSTX 0x06 /*every PC->LMS packet is started by ACKSTX*/
#define BAUD_500000 512
#define BAUD_38400 256
#define BAUD_19200 128
#define BAUD_9600 64
#define RANGE_100 32
#define RANGE_180 16
#define RES_1_DEG 8
#define RES_0_5_DEG 4
#define RES_0_25_DEG 2 
#define MMMODE 1
#define CMMODE 0
#define LMS_MAX_RANGE_8M 1
#define LMS_MAX_RANGE_16M 2
#define LMS_MAX_RANGE_32M 3


#define PROT_LMS_MODE_NOT_INIT		-1
#define PROT_LMS_MODE_INSTALLATION		0x00
#define PROT_LMS_MODE_SCAN_ON_REQUEST	0x25

#define PROT_LMS_OK						0
#define PROT_LMS_ERROR					-1
#define PROT_LMS_ERROR_NACK				-2
#define PROT_LMS_ERROR_MISS_ACK			-3
//#define PROT_LMS_ERROR_ANSWER_TIMEOUT	-4
#define PROT_LMS_ERROR_ANSWER_LENGTH	-5
//#define PROT_LMS_ERROR_READFILE		-6
#define PROT_LMS_ERROR_TELEGRAM_FORMAT  -7
#define PROT_LMS_ERROR_TELEGRAM_NACK	-8
#define PROT_LMS_ERROR_TELEGRAM_CRC     -9
#define PROT_LMS_ERROR_TELEGRAM_STATUS  -10
#define PROT_LMS_ERROR_BAD_PARAMETER	-11
#define PROT_LMS_ERROR_OPERATION_ABORTED	-12
#define PROT_LMS_ERROR_DATA_EXPECTED	-13



typedef unsigned char uchar;


/*The only 2 global variable used by the signal handler so that
  the program can reset to 9600 bps mode before unexpected termination*/
static int LMS_FD;
static struct termios OLDTERMIOS;

/*the cmd and ack packets for the 5 different range/resolution modes*/
const uchar PCLMS_RES1[]={0x02,0x00,0x05,0x00,0x3b,0x64,0x00,0x64,0x00};
const uchar PCLMS_RES2[]={0x02,0x00,0x05,0x00,0x3b,0x64,0x00,0x32,0x00};
const uchar PCLMS_RES3[]={0x02,0x00,0x05,0x00,0x3b,0x64,0x00,0x19,0x00};
const uchar PCLMS_RES4[]={0x02,0x00,0x05,0x00,0x3b,0xb4,0x00,0x64,0x00};
const uchar PCLMS_RES5[]={0x02,0x00,0x05,0x00,0x3b,0xb4,0x00,0x32,0x00};
const uchar LMSPC_RES1_ACK[]={0x06,0x02,0x80,0x07,0x00,0xbb,0x01,0x64,0x00,0x64,0x00,0x10};
const uchar LMSPC_RES2_ACK[]={0x06,0x02,0x80,0x07,0x00,0xbb,0x01,0x64,0x00,0x32,0x00,0x10};
const uchar LMSPC_RES3_ACK[]={0x06,0x02,0x80,0x07,0x00,0xbb,0x01,0x64,0x00,0x19,0x00,0x10};
const uchar LMSPC_RES4_ACK[]={0x06,0x02,0x80,0x07,0x00,0xbb,0x01,0xb4,0x00,0x64,0x00,0x10};
const uchar LMSPC_RES5_ACK[]={0x06,0x02,0x80,0x07,0x00,0xbb,0x01,0xb4,0x00,0x32,0x00,0x10};


const uchar PCLMS_RANGE_8M[50]={0x02,0x00,0x22,0x00,0x77,0x00,0x00,0x46,0x00,0x00,1,1,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
const uchar PCLMS_RANGE_16M[50]={0x02,0x00,0x22,0x00,0x77,0x00,0x00,0x46,0x00,0x00,3,1,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
const uchar PCLMS_RANGE_32M[50]={0x02,0x00,0x22,0x00,0x77,0x00,0x00,0x46,0x00,0x00,5,1,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

/*the cmd and ack packets different measurement unit modes*/
const uchar PCLMS_SETMODE[]={0x02,0x00,0x0a,0x00,0x20,0x00,0x53,0x49,0x43,0x4b,0x5f,0x4c,0x4d,0x53};
const uchar PCLMS_MM[]={0x02,0x00,0x23,0x00,0x77,
			 0x00,0x00, // Block A
			 0x46,0x00, // Block B
			 0x01,      // Block C [9]
			 0x00,      // Block D (was 0xd)
			 0x01, // Block E - 0x00 = cm, 0x01 = mm
			 0x00, // Block F
			 0x00, // Block G
			 0x02, // Block H
			 0x02, // Block I
			 0x02, // Block J
			 0x00, // Block K
			 0x00, // Block L
			 0x0a, // Block M
			 0x0a, // Block N
			 0x50, // Block O
			 0x64, // Block P
			 0x00, // Block Q
			 0x0a, // Block R
			 0x0a, // Block S
			 0x50, // Block T
			 0x80, // Block U
			 0x00, // Block V
			 0x0a, // Block W
			 0x0a, // Block X
			 0x50, // Block Y
			 0x64, // Block Z
			 0x00, // Block A1
			 0x00, // Block A2
			 0x00,0x00, // Block A3
			 0x02,0x00};// Block A4
const uchar LMSPC_MM_ACK[]={0x06,0x02,0x80,0x25,0x00,0xf7,0x01,0x00,0x00,0x46,0x00,0x01,0x0d,0x01,\
			    0x00,0x00,0x02,0x02,0x02,0x00,0x00,0x0a,0x0a,0x50,0x64,0x00,0x0a,0x0a,\
			    0x50,0x80,0x00,0x0a,0x0a,0x50,0x64,0x00,0x00,0x00,0x00,0x02,0x00,0x10};

/*the cmd packets for setting transfer speed and  controlling the start and stop of measurement*/
const uchar PCLMS_STATUS[]= {0x02,0x00,0x01,0x00,0x31};
const uchar PCLMS_START[]=  {0x02,0x00,0x02,0x00,0x20,0x24};
const uchar PCLMS_STOP[]=   {0x02,0x00,0x02,0x00,0x20,0x25};
const uchar PCLMS_B9600[] = {0x02,0x00,0x02,0x00,0x20,0x42};
const uchar PCLMS_B19200[]= {0x02,0x00,0x02,0x00,0x20,0x41};
const uchar PCLMS_B38400[]= {0x02,0x00,0x02,0x00,0x20,0x40};
const uchar PCLMS_B500000[]={0x02,0x00,0x02,0x00,0x20,0x48};
/*the ack packet for the above*/
const uchar LMSPC_CMD_ACK[]={0x06,0x02,0x80,0x03,0x00,0xa0,0x00,0x10};



class LMS200
{
public:
	LMS200();
	~LMS200();
	
	unsigned short LMSCRC(unsigned char*, int);// Calculates the CRC for packets sent to/from the LMS
	inline void printError(const char * msg){printf("%s", msg);
	// fprintf(stderr, "%s", msg);
	}
	
	inline void printError1(const char * msg, int val1){ printf("%s 0x%x\n", msg, val1);
	// fprintf(stderr, "%s 0x%x\n", msg, val1);
	}
	
	inline void printError2(const char * msg, int val1, int val2){printf("%s 0x%x 0x%x\n", msg, val1, val2);
	// fprintf(stderr, "%s 0x%x 0x%x\n", msg, val1, val2);
	}
	
	uchar msgcmp(int len1, const uchar *, int, const uchar *);// Compares two messages
	// Sleeps 55uS (minimum LMS interval between bytes)
	void sleep55us()
	{
	// This only works if the program priority is raised to real time.
	// Otherwise the usleep of 55uS actually takes 1 or more scheduling
	// intervals which can be more than the 14mS maximum interval between
	// characters for the LMS.
	// usleep(55);
	}
	void wtLMSmsg(int, int, const uchar *);// Writes a message to the LMS
	int rdLMSmsg(int, int, const uchar *);
	uchar rdLMSbyte(int);
	/*procedure that shows the laser measurements. Format: 
	Timestamp
	v0  v1  v2  ... v19
	v10 v21 v22 ... v39
	...
	The total number of measurements is dependent on the resolution
	and angular range selected*/
	void showsavedata(int , uchar *,double*);
	uchar chkAck(int, int, const uchar *);/*return true if the ACK packet is as expected*/
	int initLMS(const char *);/*set the communication speed and terminal properties*/
	void initialValues(int baud,const char* p, int range, int res, int unit, int max_r);
	int setRangeRes(int, int );// Sets the sweep width and resolution
	int setMaxRange(int fd, int m_r); //sets the maximum range of measurements
	int sendPassword(int);// Sends the password to enable changing the mode
	int setUnits(int , int );// Selects mm/cm This message causes the red signal to light on an LMS291 - reason unknown
	int startLMS(int );/*tell the scanner to enter the continuous measurement mode*/
	void stopLMS(int );/*stop the continuous measurement mode*/
	void chkstatus(uchar);/*check the status bit of the measurement*/
	void resetLMS(int);/*reset terminal and transfer speed of laser scanner before quitting*/
/*STATIC*/	void sig_trap(int);/*trap a number of signals like SIGINT, ensure the invokeof resetLMS() before quitting*/
/*STATIC*/	int connectToLMS();
	int readLMSdata(int fd,int* values);
	int baud_sel;
	char port[500];
	int range_mode;
	int res_mode;
	int unit_mode;
	int max_range;


//Initializes the laser
	int Init(const char* port="/dev/ttyUSB0");
	void Done(){stopLMS(m_fd); resetLMS(m_fd);}
//Updates the array "measurements" calling readLMS
	void Update();
//Gets a copy of measurments, blocking wiht the mutex
	int GetLaserData(int* num_med, int* meas);	
	int ChangeMode(int fd, int mod);
	
protected:
	pthread_mutex_t mutex; 
	int num_meas;
	int measurements[400];
	int new_data;
	int m_fd;  //?		
};


#endif

